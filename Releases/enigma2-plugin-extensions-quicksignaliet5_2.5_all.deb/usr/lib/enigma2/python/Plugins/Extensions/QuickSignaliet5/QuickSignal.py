# -*- coding: utf-8 -*-
## ============================================================
## QuickSignal.py - Compatibility Wrapper
## ============================================================
# Function: Provides backward compatibility for the old name "QuickSignal"
#           for any system that might import it by the old name instead
#           of QuickSignaliet5.
# Do not modify this file — your changes go into plugin.py.

import sys

# Safe import supporting both relative and absolute import methods
try:
    from . import plugin as _plugin
except Exception:
    try:
        import plugin as _plugin
    except Exception:
        _plugin = None

# Register old and new names in sys.modules for compatibility
if _plugin is not None:
    sys.modules["QuickSignal"]              = _plugin
    sys.modules["QuickSignaliet5.QuickSignal"] = _plugin

# Re-export everything from plugin.py
try:
    from .plugin import *  # noqa: F401, F403
except Exception:
    try:
        from plugin import *  # noqa: F401, F403
    except Exception:
        pass
