# -*- coding: utf-8 -*-
## ============================================================
## QuickSignalText - Converter to get BER value as a number
## (c) Original by big-town, Modified by iet5
## ============================================================
# Function: Converts BER value from FrontendStatus to an integer
# Used in skin to show the graduated BER indicator
# Compatibility: Python 2.7 and Python 3.12
# Images: All Enigma2 images (OpenATV, VTi, DreamOS, OpenSource)

import sys
from Components.Converter.Converter import Converter
from Components.Element import cached

# Python 2 and Python 3 Compatibility
PY2 = (sys.version_info[0] == 2)

# Safe import for iFrontendInformation
try:
    from enigma import iFrontendInformation
    HAS_FRONTEND_INFO = True
except Exception:
    HAS_FRONTEND_INFO = False


class QuickSignalText(Converter, object):
    """
    Converter that returns BER value as an integer.
    Used with ConditionalShowHide and ValueRange in skin
    to display graduated BER bars of different sizes.
    """

    # Supported data types
    BER_NUM = 0

    def __init__(self, type):
        Converter.__init__(self, type)
        if type == "BerNum":
            self.type = self.BER_NUM
        else:
            # Unknown type — use BER_NUM as safe default
            self.type = self.BER_NUM

    @cached
    def getValue(self):
        """
        Reads BER value from FrontendStatus and returns it as an integer.
        Uses multiple attempts to ensure compatibility across all images.
        """
        # --- Method 1: via frontend_info (available in most images) ---
        try:
            frontend_info = self.source.frontend_info
            if frontend_info is not None and HAS_FRONTEND_INFO:
                ber = frontend_info.getFrontendInfo(iFrontendInformation.ber)
                if ber is not None:
                    return int(ber)
        except Exception:
            pass

        # --- Method 2: via getValue directly from source ---
        try:
            val = self.source.value
            if val is not None:
                return int(val)
        except Exception:
            pass

        # Safe default value
        return 0

    @cached
    def getText(self):
        """Returns BER value as string."""
        return str(self.value)

    # Required properties for Enigma2 Converter
    value = property(getValue)
    text  = property(getText)
