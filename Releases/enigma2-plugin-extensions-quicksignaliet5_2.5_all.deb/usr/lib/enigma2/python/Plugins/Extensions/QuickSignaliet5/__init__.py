# -*- coding: utf-8 -*-
## ============================================================
## QuickSignaliet5 - Package Initializer
## ============================================================
# Function: Initializes the package and registers it in sys.modules.
# This file must remain simple and completely safe.
# Does not contain any code that could cause errors on import.

import sys

# Register the package in sys.modules to avoid double-import issues
# especially on DreamOS and OpenSource images that load plugins differently.
if "QuickSignaliet5" not in sys.modules:
    sys.modules["QuickSignaliet5"] = sys.modules[__name__]
