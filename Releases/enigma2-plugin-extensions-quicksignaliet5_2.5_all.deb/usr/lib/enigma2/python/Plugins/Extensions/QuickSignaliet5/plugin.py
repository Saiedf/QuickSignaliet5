# -*- coding: utf-8 -*-
## ============================================================
## QuickSignaliet5 - Signal Information Plugin for Enigma2
## Original: Quick Signal by big-town
## Modified and developed by: iet5
## ============================================================
# Purpose: Displays signal strength (SNR, AGC, BER) with the current channel logo.
# Compatibility: Python 2.7 and Python 3.12
# Devices: DreamBox 920, VU+, and all Enigma2 devices
# Images: OpenATV, VTi, DreamOS (DreamBox), OpenSource (OpenPLi and similar)

import os
import sys
import types

# ============================================================
# ----------  Python 2 and Python 3 Compatibility  ----------
# ============================================================
PY2 = (sys.version_info[0] == 2)
PY3 = not PY2

if PY2:
    # Python 2: unicode and str are different
    text_type   = unicode  # noqa: F821  # pylint: disable=undefined-variable
    string_types = (str, unicode)  # noqa: F821  # pylint: disable=undefined-variable
else:
    # Python 3: all text is str
    text_type   = str
    string_types = (str,)

# ============================================================
# ----------  Plugin Path  -----------------------------------
# ============================================================
plugin_path = os.path.dirname(os.path.realpath(__file__))
if plugin_path not in sys.path:
    sys.path.append(plugin_path)

# ============================================================
# ----------  Plugin Constants  ------------------------------
# ============================================================
PLUGIN_DISPLAY_NAME = "QuickSignaliet5"
PLUGIN_CONFIG_NAME  = "QuickSignaliet5"
LEGACY_CONFIG_NAME  = "QuickSignal"
PLUGIN_DESCRIPTION  = "Show Signal Information"

# File Paths
PLUGIN_VERSION_FILE = os.path.join(plugin_path, "version.txt")
KEYMAP_PATH         = os.path.join(plugin_path, "keymap.xml")
ICON_SNR_PATH       = os.path.join(plugin_path, "icons_quick", "icon_snr-scan.png")
ICON_BER_OFF_PATH   = os.path.join(plugin_path, "icons_quick", "icon_ber-scan_off.png")
ICON_BER_ON_PATH    = os.path.join(plugin_path, "icons_quick", "icon_ber-scan_on.png")
PLUGIN_ICON_PATH    = os.path.join(plugin_path, "plugin.png")

# ============================================================
# ----------  Core Imports  ----------------------------------
# ============================================================
from Components.config import config, ConfigSubsection, ConfigSelection, ConfigYesNo
from Components.Pixmap import Pixmap
from GlobalActions import globalActionMap
from Plugins.Plugin import PluginDescriptor
from Screens.Screen import Screen
from keymapparser import readKeymap
from enigma import eTimer, iServiceInformation

# Safe import for GetWithAlternative (available in some images only)
try:
    from Tools.Alternatives import GetWithAlternative
except Exception:
    GetWithAlternative = None

# Safe import for LoadPixmap (required for manual Picon loading)
try:
    from Tools.LoadPixmap import LoadPixmap
except Exception:
    LoadPixmap = None

# ============================================================
# ----------  Config Setup  ----------------------------------
# ============================================================
# Ensure config.plugins exists
if not hasattr(config, "plugins"):
    config.plugins = ConfigSubsection()

# Read old settings (for compatibility with the previous QuickSignal version)
try:
    legacy_config = getattr(config.plugins, LEGACY_CONFIG_NAME)
except Exception:
    legacy_config = None

# Create plugin settings if they don't exist
try:
    plugin_config = getattr(config.plugins, PLUGIN_CONFIG_NAME)
except Exception:
    setattr(config.plugins, PLUGIN_CONFIG_NAME, ConfigSubsection())
    plugin_config = getattr(config.plugins, PLUGIN_CONFIG_NAME)

# Ensure mode exists with previous value migration if found
if not hasattr(plugin_config, "mode"):
    legacy_mode = "FHD"
    try:
        if legacy_config is not None and hasattr(legacy_config, "mode"):
            legacy_mode = legacy_config.mode.value
    except Exception:
        pass
    plugin_config.mode = ConfigSelection(default=legacy_mode, choices=[("FHD", "Full HD")])

# Ensure enabled exists with previous value migration if found
if not hasattr(plugin_config, "enabled"):
    legacy_enabled = True
    try:
        if legacy_config is not None and hasattr(legacy_config, "enabled"):
            legacy_enabled = bool(legacy_config.enabled.value)
    except Exception:
        pass
    plugin_config.enabled = ConfigYesNo(default=legacy_enabled)

# Keep old config name available for backward compatibility
try:
    getattr(config.plugins, LEGACY_CONFIG_NAME)
except Exception:
    try:
        setattr(config.plugins, LEGACY_CONFIG_NAME, plugin_config)
    except Exception:
        pass

# ============================================================
# ----------  Import Local Converters  -----------------------
# ============================================================
# Imports QuickSignalText.py and QuickServiceInfo.py
# safely for both Python 2 and Python 3
def _safe_import_local(module_name):
    """Safe import for local Python files."""
    errors = []
    try:
        if PY2:
            # Python 2: uses imp.load_source
            import imp
            module_file = os.path.join(plugin_path, module_name + ".py")
            if os.path.exists(module_file):
                return imp.load_source(module_name, module_file)
        else:
            # Python 3: uses importlib
            import importlib.util
            module_file = os.path.join(plugin_path, module_name + ".py")
            if os.path.exists(module_file):
                spec = importlib.util.spec_from_file_location(module_name, module_file)
                if spec:
                    module = importlib.util.module_from_spec(spec)
                    spec.loader.exec_module(module)
                    return module
    except Exception as e:
        errors.append(str(e))

    # Fallback to standard import
    try:
        return __import__(module_name)
    except Exception as e:
        errors.append(str(e))

    print("[QuickSignaliet5] ERROR importing %s: %s" % (module_name, " | ".join(errors)))
    return None


# Load local converters
qst_mod = _safe_import_local("QuickSignalText")
qsi_mod = _safe_import_local("QuickServiceInfo")

# Ensure Components.Converter exists in sys.modules
# (Critical for DreamOS and some OpenSource images)
_components = sys.modules.get("Components")
if not _components:
    _components = types.ModuleType("Components")
    sys.modules["Components"] = _components

_conv = sys.modules.get("Components.Converter")
if not _conv:
    _conv = types.ModuleType("Components.Converter")
    setattr(_components, "Converter", _conv)
    sys.modules["Components.Converter"] = _conv

# Manually register converters to avoid missing or double registration
if qst_mod:
    sys.modules["Components.Converter.QuickSignalText"] = qst_mod
    setattr(_conv, "QuickSignalText", qst_mod)
    print("[QuickSignaliet5] QuickSignalText registered OK")

if qsi_mod:
    sys.modules["Components.Converter.QuickServiceInfo"] = qsi_mod
    setattr(_conv, "QuickServiceInfo", qsi_mod)
    print("[QuickSignaliet5] QuickServiceInfo registered OK")


# ============================================================
# ----------  Helper Functions  ------------------------------
# ============================================================

def _read_text_file(path):
    """Safely reads a text file and returns content as string."""
    try:
        if os.path.exists(path):
            with open(path, "r") as handle:
                return handle.read()
    except Exception:
        pass
    return ""


def _safe_lower(value):
    """Safely converts value to lowercase string."""
    if value is None:
        return ""
    try:
        if not isinstance(value, string_types):
            value = text_type(value)
    except Exception:
        value = str(value)
    return value.lower()


# ============================================================
# ----------  Runtime Environment Detection  -----------------
# ============================================================
# Detects image type (OpenATV, VTi, DreamOS, OpenSource)
# and hardware type (DreamBox, VU+, Generic)
def detect_runtime_environment():
    """
    Detects the full Enigma2 runtime environment.
    Used to apply different conditions for each image and device type.
    """
    info = {
        "image_family": "opensource",    # Default value
        "image_name":   "unknown",
        # Device information from /proc/stb/info
        "box_type": _safe_lower(_read_text_file("/proc/stb/info/boxtype").strip()),
        "model":    _safe_lower(_read_text_file("/proc/stb/info/model").strip()),
        "brand":    _safe_lower(_read_text_file("/proc/stb/info/vumodel").strip()),
        "box_family": "generic",
    }

    # Read image info files to identify image type
    version_blob = ""
    for v_file in [
        "/etc/image-version",
        "/etc/issue",
        "/etc/enigma2/image-version",
        "/etc/opkg/all-feed.conf",
        "/etc/opkg/official-feed.conf",
        "/etc/opkg/opkg.conf",
    ]:
        version_blob += _read_text_file(v_file) + " "

    version_blob = _safe_lower(version_blob)

    # --- Condition: Determine Image Type ---
    if "openatv" in version_blob:
        # OpenATV: needs manual Picon loading
        info["image_family"] = "openatv"
        info["image_name"]   = "openATV"

    elif "vti" in version_blob or "vuplus-oe" in version_blob:
        # VTi: uses standard Picon Renderer with specific paths
        info["image_family"] = "vti"
        info["image_name"]   = "VTI"

    elif any(x in version_blob for x in ["dreambox", "oe2.5", "oe2.6", "oe2.2", "oe-core", "dreamos"]):
        # DreamOS (DreamBox): has special picon path /data/picon
        info["image_family"] = "dreambox"
        info["image_name"]   = "DreamOS"

    elif any(x in version_blob for x in [
        "openpli", "openspa", "openhdf", "egami",
        "openbh", "openvision", "openvix", "openesi",
        "merlin", "teamblue", "beyonwiz"
    ]):
        # Other OpenSource images: use standard Picon Renderer
        info["image_family"] = "opensource"
        info["image_name"]   = "OpenSource"

    # --- Condition: Determine Device Type ---
    box_blob = " ".join([info["box_type"], info["model"], info["brand"]])

    if any(x in box_blob for x in ["vu", "vuplus", "ultimo", "uno", "duo", "solo", "zero"]):
        # VU+ devices
        info["box_family"] = "vuplus"

    elif any(x in box_blob for x in ["dream", "dm9", "dm7", "dm5", "dm8", "dm4"]):
        # DreamBox devices
        info["box_family"] = "dreambox"

    else:
        info["box_family"] = "generic"

    print("[QuickSignaliet5] Detected: image=%s, box=%s" % (
        info["image_name"], info["box_family"]
    ))
    return info


# Detect environment once on plugin load
RUNTIME_INFO = detect_runtime_environment()

# --- Core Conditions for Image Types ---
IMAGE_FAMILY = RUNTIME_INFO.get("image_family", "opensource")
BOX_FAMILY   = RUNTIME_INFO.get("box_family",   "generic")

# OpenATV: requires manual Picon loading because its renderer behaves differently
USE_MANUAL_PICON = (IMAGE_FAMILY == "openatv")

# VTi: uses standard Picon Renderer but with ServiceName>Reference
USE_VTI_PICON = (IMAGE_FAMILY == "vti")

# DreamOS: special picon path and standard Picon Renderer
USE_DREAMBOX_PICON = (IMAGE_FAMILY == "dreambox")


# ============================================================
# ----------  Picon Search Paths  ----------------------------
# ============================================================
def get_picon_search_paths():
    """
    Determines channel logo (Picon) search paths based on image and device.
    Uses specific conditions for each type to ensure the correct image is found.
    """
    search_paths = []

    # --- Condition: Special paths for DreamBox/DreamOS ---
    if IMAGE_FAMILY == "dreambox" or BOX_FAMILY == "dreambox":
        search_paths.extend([
            "/data/picon",              # Primary DreamOS path
            "/usr/share/enigma2/picon",
            "/picon",
        ])

    # --- Condition: Special paths for VU+ ---
    if BOX_FAMILY == "vuplus":
        search_paths.extend([
            "/usr/share/enigma2/picon",
            "/picon",
        ])

    # --- Condition: Special paths for VTi ---
    if IMAGE_FAMILY == "vti":
        search_paths.extend([
            "/usr/share/enigma2/picon",
            "/picon",
            "/media/hdd/picon",
        ])

    # Common paths for all images
    common_paths = [
        "/usr/share/enigma2/picon",
        "/picon",
        "/media/hdd/picon",
        "/media/usb/picon",
        "/media/mmc/picon",
        "/media/cf/picon",
        "/media/net/picon",
        "/data/picon",
    ]
    search_paths.extend(common_paths)

    # Remove duplicates and non-existent paths
    normalized_paths = []
    seen_paths = set()
    for path in search_paths:
        if not path or path in seen_paths:
            continue
        if os.path.exists(path):
            seen_paths.add(path)
            normalized_paths.append(path)

    return normalized_paths


PICON_SEARCH_PATHS = get_picon_search_paths()


# ============================================================
# ----------  Picon Search Functions  ------------------------
# ============================================================

def normalize_service_reference(service_ref):
    """Converts service reference to a unified string format."""
    if not service_ref:
        return ""

    # Convert object to string if necessary
    if hasattr(service_ref, "toString"):
        try:
            service_ref = service_ref.toString()
        except Exception:
            service_ref = ""

    if not service_ref:
        return ""

    # Use GetWithAlternative if available (gets the alternative reference)
    try:
        if GetWithAlternative is not None:
            service_ref = GetWithAlternative(service_ref)
    except Exception:
        pass

    # Ensure it's a string
    if not isinstance(service_ref, string_types):
        try:
            service_ref = text_type(service_ref)
        except Exception:
            service_ref = str(service_ref)

    service_ref = service_ref.strip()
    if not service_ref:
        return ""

    # Limit reference to 10 parts (standard Enigma2 format)
    parts = service_ref.split(":")
    if len(parts) > 10:
        service_ref = ":".join(parts[:10]) + ":"

    return service_ref


def sanitize_service_name(service_name):
    """
    Cleans service name and converts it to alphanumeric only
    for use in Picon file searching.
    Compatible with Python 2 and Python 3.
    """
    if not service_name:
        return ""

    # --- Condition: Python 2 ---
    if PY2:
        try:
            if isinstance(service_name, str):
                try:
                    service_name = service_name.decode("utf-8")
                except Exception:
                    service_name = service_name.decode("latin-1", "ignore")
            elif not isinstance(service_name, text_type):
                service_name = text_type(service_name)
        except Exception:
            try:
                service_name = text_type(str(service_name), "utf-8", "ignore")
            except Exception:
                try:
                    service_name = text_type(str(service_name), "latin-1", "ignore")
                except Exception:
                    return ""
    # --- Condition: Python 3 ---
    else:
        if isinstance(service_name, bytes):
            try:
                service_name = service_name.decode("utf-8", "ignore")
            except Exception:
                service_name = service_name.decode("latin-1", "ignore")
        elif not isinstance(service_name, text_type):
            try:
                service_name = text_type(service_name)
            except Exception:
                service_name = str(service_name)

    # Remove Enigma2 control markers (colors etc)
    try:
        service_name = service_name.replace(u"\u0086", u"").replace(u"\u0087", u"")
    except Exception:
        pass

    # Keep only alphanumeric characters (to match filename)
    cleaned = []
    for char in service_name.lower():
        try:
            if char.isalnum():
                cleaned.append(char)
        except Exception:
            pass
    return "".join(cleaned)


def build_picon_candidates(service_ref, service_name):
    """Builds a list of potential Picon filenames to search for."""
    candidates = []

    # Filter by service reference (filename is Service Reference with _ instead of :)
    normalized_ref = normalize_service_reference(service_ref)
    if normalized_ref:
        ref_parts = normalized_ref.split(":")
        ref_values = [normalized_ref]

        # Some picon packs use slightly different formats
        if len(ref_parts) >= 10:
            ref_values.append(":".join(ref_parts[:10]) + ":")
        if len(ref_parts) >= 11:
            ref_values.append(":".join(ref_parts[:11]) + ":")

        for ref_value in ref_values:
            filename = ref_value.replace(":", "_").rstrip("_") + ".png"
            candidates.extend([
                filename,
                filename.lower(),
                filename.upper(),
            ])

    # Filter by sanitized service name
    name_candidate = sanitize_service_name(service_name)
    if name_candidate:
        candidates.extend([
            name_candidate + ".png",
            name_candidate.lower() + ".png",
        ])

    # Filter by original name (with and without spaces)
    if service_name:
        service_name_text = ""
        # --- Condition: Python 2 ---
        if PY2:
            try:
                if isinstance(service_name, str):
                    try:
                        service_name_text = service_name.decode("utf-8")
                    except Exception:
                        service_name_text = service_name.decode("latin-1", "ignore")
                elif isinstance(service_name, text_type):
                    service_name_text = service_name
                else:
                    service_name_text = text_type(service_name)
            except Exception:
                service_name_text = u""
        # --- Condition: Python 3 ---
        else:
            try:
                if isinstance(service_name, bytes):
                    service_name_text = service_name.decode("utf-8", "ignore")
                else:
                    service_name_text = text_type(service_name)
            except Exception:
                service_name_text = ""

        service_name_text = service_name_text.strip()
        try:
            service_name_text = service_name_text.replace(u"\u0086", u"").replace(u"\u0087", u"")
        except Exception:
            pass

        if service_name_text:
            candidates.extend([
                service_name_text + ".png",
                service_name_text.replace(" ", "").replace("&", "and") + ".png",
            ])

    # Remove duplicates while preserving order
    unique_candidates = []
    seen_candidates = set()
    for candidate in candidates:
        if not candidate or candidate in seen_candidates:
            continue
        seen_candidates.add(candidate)
        unique_candidates.append(candidate)

    return unique_candidates


def resolve_current_picon(service_ref, service_name):
    """
    Searches for the correct Picon file in available paths.
    Returns the full file path or None if not found.
    """
    candidates = build_picon_candidates(service_ref, service_name)
    for base_path in PICON_SEARCH_PATHS:
        for candidate in candidates:
            candidate_path = os.path.join(base_path, candidate)
            if os.path.exists(candidate_path):
                return candidate_path

    # Use default image if no match found
    for base_path in PICON_SEARCH_PATHS:
        default_path = os.path.join(base_path, "picon_default.png")
        if os.path.exists(default_path):
            return default_path

    return None


# ============================================================
# ----------  Read Plugin Version  ---------------------------
# ============================================================

def read_plugin_version():
    """Reads the version number from version.txt."""
    plugin_version = "Unknown"
    try:
        with open(PLUGIN_VERSION_FILE, "r") as handle:
            plugin_version = handle.read().strip()
        if not plugin_version:
            plugin_version = "Unknown"
    except Exception as e:
        print("[QuickSignaliet5] Error reading version.txt: %s" % str(e))
        plugin_version = "Unknown"
    return plugin_version


plugin_version = read_plugin_version()
SCREEN_TITLE = "%s Info #Modified by iet5 (Ver %s)" % (PLUGIN_DISPLAY_NAME, plugin_version)


# ============================================================
# ----------  Skin Widget for Picon by Image Type  ----------
# ============================================================
# --- Condition: OpenATV ---
# Uses widget named "picon" without renderer as loading is done manually in Python
if USE_MANUAL_PICON:
    # scale="1" tells ePixmap to scale the image to fit the size (100x60)
    PICON_WIDGET_SKIN = (
        '<widget name="picon" position="135,538" size="100,60"'
        ' zPosition="3" alphatest="on" transparent="1" scale="1" />'
    )

# --- Condition: VTi, DreamOS, and OpenSource ---
# Use built-in Picon Renderer in Enigma2
else:
    PICON_WIDGET_SKIN = """\
<widget source="session.CurrentService" render="Picon" position="135,538" size="100,60" zPosition="3" alphatest="on" scale="1">
        <convert type="ServiceName">Reference</convert>
    </widget>"""


# ============================================================
# ----------  User Interface Skin (Full HD)  -----------------
# ============================================================
SKIN = """
<screen position="50,65" size="1180,625" title="%s" zPosition="1">

    <!-- SNR value in dB at the top -->
    <widget source="session.FrontendStatus" render="Label" position="420,20" zPosition="2" size="360,50" font="Regular;45" foregroundColor="#AAAAAA" halign="center" valign="center" transparent="1">
        <convert type="FrontendInfo">SNRdB</convert>
    </widget>

    <!-- SNR - Signal-to-Noise Ratio -->
    <eLabel name="snr" text="SNR:" position="5,110" size="100,35" font="Regular;33" halign="right" foregroundColor="#AAAAAA" transparent="1" />
    <widget source="session.FrontendStatus" render="Progress" position="135,80" size="910,100" pixmap="%s" zPosition="2" borderWidth="4" borderColor="#656565">
        <convert type="FrontendInfo">SNR</convert>
    </widget>
    <widget source="session.FrontendStatus" render="Label" position="1080,110" size="100,35" font="Regular;33" foregroundColor="#AAAAAA" transparent="1">
        <convert type="FrontendInfo">SNR</convert>
    </widget>

    <!-- AGC - Automatic Gain Control -->
    <eLabel name="agc" text="AGC:" position="5,240" size="100,35" font="Regular;33" halign="right" foregroundColor="#AAAAAA" transparent="1" />
    <widget source="session.FrontendStatus" render="Progress" position="135,210" size="910,100" pixmap="%s" zPosition="2" borderWidth="4" borderColor="#656565">
        <convert type="FrontendInfo">AGC</convert>
    </widget>
    <widget source="session.FrontendStatus" render="Label" position="1080,240" size="100,35" font="Regular;33" foregroundColor="#AAAAAA" transparent="1">
        <convert type="FrontendInfo">AGC</convert>
    </widget>

    <!-- BER - Bit Error Rate -->
    <eLabel name="ber" text="BER:" position="5,370" size="100,35" font="Regular;33" halign="right" foregroundColor="#AAAAAA" transparent="1" />
    <widget source="session.FrontendStatus" render="Progress" position="135,340" size="910,100" pixmap="%s" zPosition="1" borderWidth="4" borderColor="#656565">
        <convert type="FrontendInfo">BER</convert>
    </widget>
    <widget source="session.FrontendStatus" render="Label" position="320,450" size="540,40" font="Regular;38" foregroundColor="#AAAAAA" halign="center" valign="center" transparent="1">
        <convert type="FrontendInfo">BER</convert>
    </widget>

    <!-- Graduated BER Indicators (shows a growing bar as BER value increases) -->
    <widget source="session.FrontendStatus" render="Pixmap" position="135,340" size="4,100"   zPosition="2" pixmap="%s" transparent="1"><convert type="QuickSignalText">BerNum</convert> <convert type="ValueRange">1,10</convert> <convert type="ConditionalShowHide"/></widget>
    <widget source="session.FrontendStatus" render="Pixmap" position="135,340" size="8,100"   zPosition="2" pixmap="%s" transparent="1"><convert type="QuickSignalText">BerNum</convert> <convert type="ValueRange">11,20</convert> <convert type="ConditionalShowHide"/></widget>
    <widget source="session.FrontendStatus" render="Pixmap" position="135,340" size="12,100"  zPosition="2" pixmap="%s" transparent="1"><convert type="QuickSignalText">BerNum</convert> <convert type="ValueRange">21,30</convert> <convert type="ConditionalShowHide"/></widget>
    <widget source="session.FrontendStatus" render="Pixmap" position="135,340" size="16,100"  zPosition="2" pixmap="%s" transparent="1"><convert type="QuickSignalText">BerNum</convert> <convert type="ValueRange">31,40</convert> <convert type="ConditionalShowHide"/></widget>
    <widget source="session.FrontendStatus" render="Pixmap" position="135,340" size="20,100"  zPosition="2" pixmap="%s" transparent="1"><convert type="QuickSignalText">BerNum</convert> <convert type="ValueRange">41,50</convert> <convert type="ConditionalShowHide"/></widget>
    <widget source="session.FrontendStatus" render="Pixmap" position="135,340" size="25,100"  zPosition="2" pixmap="%s" transparent="1"><convert type="QuickSignalText">BerNum</convert> <convert type="ValueRange">51,60</convert> <convert type="ConditionalShowHide"/></widget>
    <widget source="session.FrontendStatus" render="Pixmap" position="135,340" size="30,100"  zPosition="2" pixmap="%s" transparent="1"><convert type="QuickSignalText">BerNum</convert> <convert type="ValueRange">61,70</convert> <convert type="ConditionalShowHide"/></widget>
    <widget source="session.FrontendStatus" render="Pixmap" position="135,340" size="35,100"  zPosition="2" pixmap="%s" transparent="1"><convert type="QuickSignalText">BerNum</convert> <convert type="ValueRange">71,80</convert> <convert type="ConditionalShowHide"/></widget>
    <widget source="session.FrontendStatus" render="Pixmap" position="135,340" size="40,100"  zPosition="2" pixmap="%s" transparent="1"><convert type="QuickSignalText">BerNum</convert> <convert type="ValueRange">81,90</convert> <convert type="ConditionalShowHide"/></widget>
    <widget source="session.FrontendStatus" render="Pixmap" position="135,340" size="45,100"  zPosition="2" pixmap="%s" transparent="1"><convert type="QuickSignalText">BerNum</convert> <convert type="ValueRange">91,100</convert> <convert type="ConditionalShowHide"/></widget>
    <widget source="session.FrontendStatus" render="Pixmap" position="135,340" size="50,100"  zPosition="2" pixmap="%s" transparent="1"><convert type="QuickSignalText">BerNum</convert> <convert type="ValueRange">101,200</convert> <convert type="ConditionalShowHide"/></widget>
    <widget source="session.FrontendStatus" render="Pixmap" position="135,340" size="55,100"  zPosition="2" pixmap="%s" transparent="1"><convert type="QuickSignalText">BerNum</convert> <convert type="ValueRange">201,300</convert> <convert type="ConditionalShowHide"/></widget>
    <widget source="session.FrontendStatus" render="Pixmap" position="135,340" size="60,100"  zPosition="2" pixmap="%s" transparent="1"><convert type="QuickSignalText">BerNum</convert> <convert type="ValueRange">301,400</convert> <convert type="ConditionalShowHide"/></widget>
    <widget source="session.FrontendStatus" render="Pixmap" position="135,340" size="65,100"  zPosition="2" pixmap="%s" transparent="1"><convert type="QuickSignalText">BerNum</convert> <convert type="ValueRange">401,500</convert> <convert type="ConditionalShowHide"/></widget>
    <widget source="session.FrontendStatus" render="Pixmap" position="135,340" size="70,100"  zPosition="2" pixmap="%s" transparent="1"><convert type="QuickSignalText">BerNum</convert> <convert type="ValueRange">501,600</convert> <convert type="ConditionalShowHide"/></widget>
    <widget source="session.FrontendStatus" render="Pixmap" position="135,340" size="75,100"  zPosition="2" pixmap="%s" transparent="1"><convert type="QuickSignalText">BerNum</convert> <convert type="ValueRange">601,700</convert> <convert type="ConditionalShowHide"/></widget>
    <widget source="session.FrontendStatus" render="Pixmap" position="135,340" size="80,100"  zPosition="2" pixmap="%s" transparent="1"><convert type="QuickSignalText">BerNum</convert> <convert type="ValueRange">701,800</convert> <convert type="ConditionalShowHide"/></widget>
    <widget source="session.FrontendStatus" render="Pixmap" position="135,340" size="85,100"  zPosition="2" pixmap="%s" transparent="1"><convert type="QuickSignalText">BerNum</convert> <convert type="ValueRange">801,900</convert> <convert type="ConditionalShowHide"/></widget>
    <widget source="session.FrontendStatus" render="Pixmap" position="135,340" size="90,100"  zPosition="2" pixmap="%s" transparent="1"><convert type="QuickSignalText">BerNum</convert> <convert type="ValueRange">901,1000</convert> <convert type="ConditionalShowHide"/></widget>
    <widget source="session.FrontendStatus" render="Pixmap" position="135,340" size="95,100"  zPosition="2" pixmap="%s" transparent="1"><convert type="QuickSignalText">BerNum</convert> <convert type="ValueRange">1001,5000</convert> <convert type="ConditionalShowHide"/></widget>
    <widget source="session.FrontendStatus" render="Pixmap" position="135,340" size="100,100" zPosition="2" pixmap="%s" transparent="1"><convert type="QuickSignalText">BerNum</convert> <convert type="ValueRange">5001,10000</convert> <convert type="ConditionalShowHide"/></widget>
    <widget source="session.FrontendStatus" render="Pixmap" position="135,340" size="150,100" zPosition="2" pixmap="%s" transparent="1"><convert type="QuickSignalText">BerNum</convert> <convert type="ValueRange">9001,10000</convert> <convert type="ConditionalShowHide"/></widget>
    <widget source="session.FrontendStatus" render="Pixmap" position="135,340" size="200,100" zPosition="2" pixmap="%s" transparent="1"><convert type="QuickSignalText">BerNum</convert> <convert type="ValueRange">10001,50000</convert> <convert type="ConditionalShowHide"/></widget>
    <widget source="session.FrontendStatus" render="Pixmap" position="135,340" size="250,100" zPosition="2" pixmap="%s" transparent="1"><convert type="QuickSignalText">BerNum</convert> <convert type="ValueRange">50001,100001</convert> <convert type="ConditionalShowHide"/></widget>
    <widget source="session.FrontendStatus" render="Pixmap" position="135,340" size="400,100" zPosition="2" pixmap="%s" transparent="1"><convert type="QuickSignalText">BerNum</convert> <convert type="ValueRange">100001,150000</convert> <convert type="ConditionalShowHide"/></widget>
    <widget source="session.FrontendStatus" render="Pixmap" position="135,340" size="600,100" zPosition="2" pixmap="%s" transparent="1"><convert type="QuickSignalText">BerNum</convert> <convert type="ValueRange">150001,200000</convert> <convert type="ConditionalShowHide"/></widget>
    <widget source="session.FrontendStatus" render="Pixmap" position="135,340" size="700,100" zPosition="2" pixmap="%s" transparent="1"><convert type="QuickSignalText">BerNum</convert> <convert type="ValueRange">200001,250000</convert> <convert type="ConditionalShowHide"/></widget>
    <widget source="session.FrontendStatus" render="Pixmap" position="135,340" size="800,100" zPosition="2" pixmap="%s" transparent="1"><convert type="QuickSignalText">BerNum</convert> <convert type="ValueRange">250001,319999</convert> <convert type="ConditionalShowHide"/></widget>
    <widget source="session.FrontendStatus" render="Pixmap" position="135,340" size="910,100" zPosition="2" pixmap="%s" transparent="1"><convert type="QuickSignalText">BerNum</convert> <convert type="ValueRange">320000,320000</convert> <convert type="ConditionalShowHide"/></widget>

    <!-- Picon: Current channel logo (changes based on image type defined above) -->
    %s

    <!-- Channel Name and Provider -->
    <widget source="session.CurrentService" render="Label" position="260,540" size="340,30" font="Regular;25" backgroundColor="#000000" foregroundColor="#CCCCCC" transparent="1">
        <convert type="ServiceName">Name</convert>
    </widget>
    <widget source="session.CurrentService" render="Label" position="260,575" size="240,25" font="Regular;20" backgroundColor="#000000" foregroundColor="#AAAAAA" transparent="1">
        <convert type="ServiceName">Provider</convert>
    </widget>

    <!-- Transponder Information: Frequency, Polarity, Symbol Rate, FEC -->
    <widget source="session.CurrentService" render="Label" position="640,540" size="400,35" font="Regular;32" halign="right" backgroundColor="#000000" foregroundColor="#AAAAAA" transparent="1">
        <convert type="QuickServiceInfo">All</convert>
    </widget>
    <widget source="session.CurrentService" render="Label" position="590,575" size="450,28" font="Regular;25" halign="right" backgroundColor="#000000" foregroundColor="#AAAAAA" transparent="1">
        <convert type="QuickServiceInfo">SatName</convert>
    </widget>

</screen>
""" % (
    SCREEN_TITLE,
    ICON_SNR_PATH,    # SNR progress bar
    ICON_SNR_PATH,    # AGC progress bar
    ICON_BER_OFF_PATH,  # BER progress bar (background)
    # BER indicators (x28)
    ICON_BER_ON_PATH, ICON_BER_ON_PATH, ICON_BER_ON_PATH, ICON_BER_ON_PATH,
    ICON_BER_ON_PATH, ICON_BER_ON_PATH, ICON_BER_ON_PATH, ICON_BER_ON_PATH,
    ICON_BER_ON_PATH, ICON_BER_ON_PATH, ICON_BER_ON_PATH, ICON_BER_ON_PATH,
    ICON_BER_ON_PATH, ICON_BER_ON_PATH, ICON_BER_ON_PATH, ICON_BER_ON_PATH,
    ICON_BER_ON_PATH, ICON_BER_ON_PATH, ICON_BER_ON_PATH, ICON_BER_ON_PATH,
    ICON_BER_ON_PATH, ICON_BER_ON_PATH, ICON_BER_ON_PATH, ICON_BER_ON_PATH,
    ICON_BER_ON_PATH, ICON_BER_ON_PATH, ICON_BER_ON_PATH, ICON_BER_ON_PATH,
    ICON_BER_ON_PATH,  # 29th BER indicator (was missing — caused the crash)
    PICON_WIDGET_SKIN,
)


# ============================================================
# ----------  Main Screen Class  -----------------------------
# ============================================================
class QuickSignalScreen(Screen):
    """
    Main screen class for displaying signal information.
    Supports all image types and devices with specific conditions for each.
    """

    def __init__(self, session):
        self.skin = SKIN
        Screen.__init__(self, session)

        # Internal visibility flag
        self._visible = False
        self._last_service_ref = ""
        self._last_picon_path  = None

        # Bind show and hide events to keep _dialog_shown synchronized
        self.onShow.append(self._onShow)
        self.onHide.append(self._onHide)

        # --- Condition: Only OpenATV needs manual Picon loading ---
        if USE_MANUAL_PICON:
            self["picon"] = Pixmap()
            self.picon_timer = eTimer()
            self._connect_timer(self.picon_timer, self._onPiconTimer)
            self.onLayoutFinish.append(self._onLayoutFinish)

    # ----------------------------------------------------------
    # Connect Timer safely (API differs between old and new Enigma2)
    # ----------------------------------------------------------
    def _connect_timer(self, timer, callback):
        """Connects callback function to Timer in a compatible way."""
        try:
            # Python callback method (Classic — DreamOS, VTi, OpenSource)
            timer.callback.append(callback)
        except Exception:
            try:
                # Qt signal method (Modern — OpenATV, some newer images)
                timer.timeout.connect(callback)
            except Exception:
                pass

    # ----------------------------------------------------------
    # Screen Events
    # ----------------------------------------------------------
    def _onLayoutFinish(self):
        """Executed after layout drawing is complete - Only for OpenATV."""
        if USE_MANUAL_PICON:
            self.updatePicon(force=True)

    def _onShow(self):
        """Executed when the screen is shown."""
        global _dialog_shown
        _dialog_shown = True
        self._visible = True
        # --- Condition: OpenATV - Update Picon and start timer ---
        if USE_MANUAL_PICON:
            self.updatePicon(force=True)
            self._startPiconTimer()

    def _onHide(self):
        """Executed when the screen is hidden."""
        global _dialog_shown
        _dialog_shown = False
        self._visible = False
        # --- Condition: OpenATV - Stop timer ---
        if USE_MANUAL_PICON:
            try:
                self.picon_timer.stop()
            except Exception:
                pass

    def _startPiconTimer(self):
        """Starts Picon update timer (every 1.5 seconds)."""
        if not USE_MANUAL_PICON:
            return
        try:
            # singleShot=True: executes once then restarted in callback
            self.picon_timer.start(1500, True)
        except Exception:
            try:
                self.picon_timer.start(1500)
            except Exception:
                pass

    def _onPiconTimer(self):
        """Executed on timer cycles to update Picon when channel changes."""
        if not USE_MANUAL_PICON:
            return
        if not self._visible:
            return
        self.updatePicon(force=False)
        self._startPiconTimer()

    # ----------------------------------------------------------
    # Get Current Service Reference and Name
    # ----------------------------------------------------------
    def _getCurrentServiceReference(self):
        """Returns the current service reference as a string."""
        reference = ""

        # Attempt 1: getCurrentlyPlayingServiceReference
        try:
            current_ref = self.session.nav.getCurrentlyPlayingServiceReference()
            if current_ref is not None:
                reference = normalize_service_reference(current_ref)
        except Exception:
            reference = ""

        if reference:
            return reference

        # Attempt 2: via service info
        try:
            service = self.session.nav.getCurrentService()
            info = service and service.info()
            if info is not None:
                reference = info.getInfoString(iServiceInformation.sServiceref)
                reference = normalize_service_reference(reference)
        except Exception:
            reference = ""

        return reference

    def _getCurrentServiceName(self):
        """Returns the current service name."""
        try:
            service = self.session.nav.getCurrentService()
            info = service and service.info()
            if info is not None:
                name = info.getName()
                if not name:
                    return ""
                # --- Condition: Python 2 ---
                if PY2 and isinstance(name, str):
                    try:
                        name = name.decode("utf-8")
                    except Exception:
                        name = name.decode("latin-1", "ignore")
                # --- Condition: Python 3 ---
                elif PY3 and isinstance(name, bytes):
                    name = name.decode("utf-8", "ignore")
                # Remove Enigma2 special markers
                try:
                    name = name.replace(u"\u0086", u"").replace(u"\u0087", u"")
                except Exception:
                    pass
                return name
        except Exception:
            pass
        return ""

    # ----------------------------------------------------------
    # Display Picon - Only for OpenATV (USE_MANUAL_PICON)
    # ----------------------------------------------------------
    def _showResolvedPicon(self, picon_path):
        """
        Loads and displays Picon in the widget.
        Used only on OpenATV where manual loading is required.
        """
        if not USE_MANUAL_PICON:
            return

        pixmap_widget = self["picon"]

        if picon_path:
            try:
                # Load Image
                pixmap_data = None
                if LoadPixmap is not None:
                    try:
                        pixmap_data = LoadPixmap(path=picon_path)
                    except Exception:
                        try:
                            pixmap_data = LoadPixmap(picon_path)
                        except Exception:
                            pixmap_data = None

                if pixmap_data is not None and pixmap_widget.instance is not None:
                    # ==============================================
                    # Final solution for Logo size in OpenATV:
                    # Using three consecutive fallback methods
                    # ==============================================

                    picon_set = False

                    # --- Method 1: setScale then setPixmap (Recommended for Enigma2) ---
                    if not picon_set:
                        try:
                            pixmap_widget.instance.setScale(1)  # 1 = Enable automatic scaling
                            pixmap_widget.instance.setPixmap(pixmap_data)
                            picon_set = True
                        except Exception:
                            pass

                    # --- Method 2: Manual scaling using ePixmap.setPixmapScaleCheck ---
                    if not picon_set:
                        try:
                            from enigma import BT_SCALE, BT_KEEP_ASPECT_RATIO
                            pixmap_widget.instance.setPixmap(
                                pixmap_data,
                                BT_SCALE | BT_KEEP_ASPECT_RATIO
                            )
                            picon_set = True
                        except Exception:
                            pass

                    # --- Method 3: Set pixmap directly (Final fallback) ---
                    if not picon_set:
                        try:
                            pixmap_widget.instance.setPixmap(pixmap_data)
                            picon_set = True
                        except Exception:
                            pass

                elif pixmap_widget.instance is not None and hasattr(pixmap_widget.instance, "setPixmapFromFile"):
                    # Some Enigma2 versions support setPixmapFromFile directly
                    pixmap_widget.instance.setPixmapFromFile(picon_path)
                else:
                    return

                # Show widget
                try:
                    pixmap_widget.show()
                except Exception:
                    pass

                self._last_picon_path = picon_path
                return

            except Exception as e:
                print("[QuickSignaliet5] Failed to load picon %s: %s" % (picon_path, e))

        # Hide widget if no picon found
        try:
            pixmap_widget.hide()
        except Exception:
            pass
        self._last_picon_path = None

    def updatePicon(self, force=False):
        """Updates Picon if channel changed."""
        if not USE_MANUAL_PICON:
            return

        service_ref  = self._getCurrentServiceReference()
        service_name = self._getCurrentServiceName()
        picon_path   = resolve_current_picon(service_ref, service_name)

        # Skip update if nothing changed (unless forced)
        if not force and service_ref == self._last_service_ref and picon_path == self._last_picon_path:
            return

        self._last_service_ref = service_ref
        self._showResolvedPicon(picon_path)


# ============================================================
# ----------  Main Plugin Class  -----------------------------
# ============================================================

# Simple visibility flag — avoids complex detection logic that caused errors
_dialog_shown = False


class QuickSignal(object):
    """Manages Dialog creation, keymap registration, and actions."""

    def __init__(self):
        self.dialog = None

    def gotSession(self, session):
        global globalActionMap

        # Load keymap safely
        try:
            if os.path.exists(KEYMAP_PATH):
                readKeymap(KEYMAP_PATH)
        except Exception as e:
            print("[QuickSignaliet5] keymap read error: %s" % e)

        # Create Dialog once only
        if self.dialog is None:
            self.dialog = session.instantiateDialog(QuickSignalScreen)
            # Ensure plugin starts hidden
            try:
                plugin_config.enabled.value = False
            except Exception:
                pass

        # Register ShowHide action in globalActionMap
        globalActionMap.actions["showQuickSignal"] = ShowHide


# Create plugin instance
pSignal = QuickSignal()


# ============================================================
# ----------  Show/Hide Function  ----------------------------
# ============================================================
def ShowHide():
    """
    Shows or hides the screen based on _dialog_shown flag.
    Called from TXT/TEXT button on remote control.
    """
    global _dialog_shown

    if pSignal.dialog is None:
        return

    if _dialog_shown:
        # Screen is visible -> Hide it
        _dialog_shown = False
        try:
            plugin_config.enabled.value = False
        except Exception:
            pass
        try:
            pSignal.dialog.hide()
        except Exception as e:
            print("[QuickSignaliet5] hide() error: %s" % e)
    else:
        # Screen is hidden -> Show it
        _dialog_shown = True
        try:
            plugin_config.enabled.value = True
        except Exception:
            pass
        try:
            pSignal.dialog.show()
        except Exception as e:
            print("[QuickSignaliet5] show() error: %s" % e)


# ============================================================
# ----------  Session Start Hooks  ---------------------------
# ============================================================
def sessionstart(reason, **kwargs):
    """Executed when Enigma2 session starts."""
    if reason == 0 and "session" in kwargs:
        pSignal.gotSession(kwargs["session"])


def main(session, **kwargs):
    """Entry point when running plugin from menu."""
    if pSignal.dialog is None:
        pSignal.gotSession(session)
    ShowHide()


# ============================================================
# ----------  Plugin Registration in Enigma2  ----------------
# ============================================================
def Plugins(**kwargs):
    """Returns list of plugin registration points in Enigma2."""
    print("[QuickSignaliet5] Plugins() called — image: %s, box: %s" % (
        RUNTIME_INFO.get("image_name", "?"),
        RUNTIME_INFO.get("box_family", "?")
    ))

    # Build plugin description for extensions menu
    main_descriptor_kwargs = {
        "name":        PLUGIN_DISPLAY_NAME,
        "description": PLUGIN_DESCRIPTION,
        "where":       PluginDescriptor.WHERE_EXTENSIONSMENU,
        "fnc":         main,
    }
    # Add plugin icon if exists
    if os.path.exists(PLUGIN_ICON_PATH):
        main_descriptor_kwargs["icon"] = "plugin.png"

    return [
        PluginDescriptor(**main_descriptor_kwargs),
        PluginDescriptor(
            where=PluginDescriptor.WHERE_SESSIONSTART,
            fnc=sessionstart
        ),
    ]