# -*- coding: utf-8 -*-
## ============================================================
## QuickServiceInfo - Converter to display frequency and satellite info
## (c) 2010 by SatCat, Modified by iet5 for QuickSignaliet5
## ============================================================
# Function: Extracts frequency, polarity, FEC, and satellite name
#           from the current service and displays it in the skin.
# Compatibility: Python 2.7 and Python 3.12
# Images:   OpenATV, VTi, DreamOS, OpenSource (All Enigma2 images)

import os
import sys

# Python 2 and Python 3 Compatibility
PY2 = (sys.version_info[0] == 2)
PY3 = not PY2

from Components.Converter.Converter import Converter
from Components.Element import cached

# Safe import for required libraries
try:
    from enigma import iServiceInformation, iFrontendInformation
    from enigma import eDVBFrontendParametersSatellite
    HAS_ENIGMA_IMPORTS = True
except Exception:
    HAS_ENIGMA_IMPORTS = False

try:
    from enigma import eServiceCenter, eServiceReference
    HAS_SERVICE_CENTER = True
except Exception:
    HAS_SERVICE_CENTER = False

# Safe import for XML Parser
try:
    from xml.etree.cElementTree import parse as xml_parse
    HAS_XML = True
except Exception:
    try:
        from xml.etree.ElementTree import parse as xml_parse
        HAS_XML = True
    except Exception:
        HAS_XML = False


class QuickServiceInfo(Converter, object):
    """
    Converter that returns frequency and satellite info for the current service.
    Supports types: All, Freq, SR, Polar, FEC, Ver, ServNum, SatName, ServRef
    """

    # Supported information types
    ALL     = 0
    FREQ    = 1
    SR      = 2
    POLAR   = 3
    FEC     = 4
    VER     = 5
    SERVNUM = 6
    SATNAME = 7
    SERVREF = 8

    # Polarity Map
    POLAR_MAP = {"0": "H", "1": "V", "2": "L", "3": "R"}

    # FEC Rate Map
    FEC_MAP = {
        "0": "AUTO", "1": "1/2", "2": "2/3", "3": "3/4",
        "4": "5/6",  "5": "7/8", "6": "8/9", "7": "3/5",
        "8": "4/5",  "9": "9/10", "15": "None"
    }

    def __init__(self, type):
        Converter.__init__(self, type)

        # Service and Satellite lists
        self.SatLst     = {}   # Service Reference -> Channel Number
        self.SatLst2    = {}   # Service Name      -> Channel Number
        self.SatNameLst = {}   # Orbital Position  -> Satellite Name

        # Load channel lists on initialization
        self._loadChannelLists()

        # Load satellite names from satellites.xml
        self._loadSatelliteNames()

        # Set requested information type
        type_map = {
            "All":     self.ALL,
            "Freq":    self.FREQ,
            "SR":      self.SR,
            "Polar":   self.POLAR,
            "FEC":     self.FEC,
            "Ver":     self.VER,
            "ServNum": self.SERVNUM,
            "SatName": self.SATNAME,
            "ServRef": self.SERVREF,
        }
        self.type = type_map.get(type, self.ALL)

    def _loadChannelLists(self):
        """Loads channel lists from Bouquets to calculate channel number."""
        if not HAS_SERVICE_CENTER:
            return
        try:
            # TV Channels
            self._getServList(eServiceReference(
                '1:7:1:0:0:0:0:0:0:0:(type == 1) || (type == 17) || '
                '(type == 195) || (type == 25) FROM BOUQUET "bouquets.tv" ORDER BY bouquet'
            ))
            # Radio Channels
            self._getServList(eServiceReference(
                '1:7:2:0:0:0:0:0:0:0:(type == 2) FROM BOUQUET "bouquets.radio" ORDER BY bouquet'
            ))
        except Exception as e:
            print("[QuickServiceInfo] Error loading channel lists: %s" % str(e))

    def _getServList(self, eSRef):
        """Enumerates Bouquet services and stores their numbers."""
        if not HAS_SERVICE_CENTER:
            return
        try:
            tot_num = len(self.SatLst)  # Continue counting from last number
            hService = eServiceCenter.getInstance()
            if hService is None:
                return
            services = hService.list(eSRef)
            bouquets = services and services.getContent("SN", True)
            for bq in (bouquets or []):
                try:
                    srv = hService.list(eServiceReference(bq[0]))
                    chs = srv and srv.getContent("SN", True)
                    for ch in (chs or []):
                        try:
                            # Skip markers
                            if not ch[0].startswith("1:64:"):
                                tot_num += 1
                                self.SatLst[ch[0]]  = tot_num
                                self.SatLst2[ch[1]] = tot_num
                        except Exception:
                            pass
                except Exception:
                    pass
        except Exception as e:
            print("[QuickServiceInfo] Error in _getServList: %s" % str(e))

    def _loadSatelliteNames(self):
        """Loads satellite names from /etc/tuxbox/satellites.xml."""
        if not HAS_XML:
            return
        sat_xml_path = "/etc/tuxbox/satellites.xml"
        if not os.path.exists(sat_xml_path):
            return
        try:
            xml_root = xml_parse(sat_xml_path).getroot()
            if xml_root is not None:
                for sat in xml_root.findall("sat"):
                    sname = sat.get("name", "")
                    spos  = sat.get("position", "")
                    if sname and spos:
                        self.SatNameLst[spos] = sname
        except Exception as e:
            print("[QuickServiceInfo] Error parsing satellites.xml: %s" % str(e))

    @cached
    def getText(self):
        """
        Returns requested text based on self.type.
        Handles all cases safely.
        """
        # --- VER: Constant version ---
        if self.type == self.VER:
            return "2.0"

        if not HAS_ENIGMA_IMPORTS:
            return ""

        # Get Current Service
        try:
            service = self.source.service
            info    = service and service.info()
        except Exception:
            return ""

        if not info:
            return ""

        # --- SERVREF: Service Reference ---
        if self.type == self.SERVREF:
            try:
                return info.getInfoString(iServiceInformation.sServiceref) or ""
            except Exception:
                return ""

        # --- SERVNUM: Channel Number ---
        if self.type == self.SERVNUM:
            try:
                chnl = info.getInfoString(iServiceInformation.sServiceref) or ""
                if chnl in self.SatLst:
                    return str(self.SatLst[chnl])
                name = self._safe_get_name(info)
                if name in self.SatLst2:
                    return str(self.SatLst2[name])
                return "0"
            except Exception:
                return "0"

        # Get TransponderData
        tpi = None
        try:
            tpi = info.getInfoObject(iServiceInformation.sTransponderData)
        except Exception:
            pass

        if tpi is None:
            return ""

        # Extract frequency
        try:
            freq = (tpi.get("frequency", 0) or 0) // 1000
        except Exception:
            freq = 0

        # --- FREQ: Frequency ---
        if self.type == self.FREQ:
            return str(freq)

        # Extract polarity
        polar = "?"
        try:
            if "polarization" in tpi:
                polar = self.POLAR_MAP.get(str(tpi["polarization"]), "?")
        except Exception:
            polar = "?"

        # --- POLAR: Polarity ---
        if self.type == self.POLAR:
            return polar

        # Extract symbol rate
        try:
            sr = (tpi.get("symbol_rate", 0) or tpi.get("symbolrate", 0) or 0) // 1000
        except Exception:
            sr = 0

        # --- SR: Symbol Rate ---
        if self.type == self.SR:
            return str(sr)

        # Extract FEC
        fec = "?"
        try:
            if "fec_inner" in tpi:
                fec = self.FEC_MAP.get(str(tpi["fec_inner"]), "?")
        except Exception:
            fec = "?"

        # --- FEC: Forward Error Correction ---
        if self.type == self.FEC:
            return fec

        # --- SATNAME: Satellite Name ---
        if self.type == self.SATNAME:
            try:
                orb = str(tpi.get("orbital_position", ""))
                if orb in self.SatNameLst:
                    return self.SatNameLst[orb]
            except Exception:
                pass
            return "----"

        # --- ALL: Combined transponder info ---
        if self.type == self.ALL:
            try:
                return "%d %s %d %s" % (freq, polar, sr, fec)
            except Exception:
                return ""

        return ""

    def _safe_get_name(self, info):
        """Returns service name safely compatible with Python 2 and Python 3."""
        try:
            name = info.getName()
            if not name:
                return ""
            # --- Condition: Python 2 ---
            if PY2 and isinstance(name, str):
                try:
                    name = name.decode("utf-8")
                except Exception:
                    name = name.decode("latin-1", "ignore")
            # --- Condition: Python 3 ---
            elif PY3 and isinstance(name, bytes):
                name = name.decode("utf-8", "ignore")
            return name
        except Exception:
            return ""

    text = property(getText)
